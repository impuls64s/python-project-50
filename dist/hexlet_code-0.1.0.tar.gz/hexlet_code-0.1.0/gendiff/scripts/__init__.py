# -*- coding:utf-8 -*-

"""Script examples."""
