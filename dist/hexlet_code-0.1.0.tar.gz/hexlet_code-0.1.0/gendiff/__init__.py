"""Main module."""

from gendiff.generator import generate_diff

__all__ = ["generate_diff"]