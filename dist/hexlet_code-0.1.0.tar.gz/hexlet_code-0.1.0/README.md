### Hexlet tests and linter status:
[![Actions Status](https://github.com/impuls64s/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/impuls64s/python-project-50/actions)
<a href="https://codeclimate.com/github/impuls64s/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/3feee94e951e899c72b0/maintainability" /></a>
<a href="https://codeclimate.com/github/impuls64s/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/3feee94e951e899c72b0/test_coverage" /></a>
[![GitHub Actions Demo](https://github.com/impuls64s/python-project-50/actions/workflows/github-actions-demo.yml/badge.svg)](https://github.com/impuls64s/python-project-50/actions/workflows/github-actions-demo.yml)
