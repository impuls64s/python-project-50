import argparse
from ..generate_diff import generate_diff


def gendiff():
    parser = argparse.ArgumentParser(description=(f'Compares two configuration '
                                                  f'files and shows a difference.'))
    parser.add_argument("first_file")
    parser.add_argument("second_file")
    parser.add_argument('-f FORMAT', '--format FORMAT', 
                        help='set format of output', action="store_true")
    args = parser.parse_args()
    args1, args2 = args.first_file, args.second_file
    generate_diff(args1, args2)

 
def main():
    gendiff()


if __name__ == '__main__':
    main()

